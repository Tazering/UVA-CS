The boilerplate code for p2exp2. Place the directory like this: 
p2-concurrency/
    + exp2-assignment/

`hashtable-biglock.c`: a sample hashtable implementation that showcases the hashtable APIs. It should work. It's thread safe by using a big lock. 
To scale it, search for "TODO" 

To build it, use `cmake .` then `make` 



run.sh: sample commands for building, testing, and benchmarking hashtable. Tweak them. 

teacher-only/ contains some archived boilerplate code. 
